# LunarLander
Physics model for Lunar Lander for kv5002

Please use the following commands to run the program

```shell
$ java -jar LunarLander.jar
```

use the following commands to compile and run the program

```shell
$ make clean
$ make 
$ java -jar LunarLander.jar
```

